#include "BoardDisplay.h"

using namespace std;

BoardDisplay::BoardDisplay(string layout): BoardLayout{layout} {}

BoardDisplay::~BoardDisplay() {}
